package org.iitwf.selenium.lib;

import java.util.Hashtable;

public class ExceptionEx {
	public static void main(String[] args) {

		
		//double d = Double.parseDouble("12.34$");
		
		Hashtable<String,String> hMap = new Hashtable<String,String>();
//		int i =5;
//		Integer i1 = new Integer(i);
		hMap.put("name","John");

//		String value = hMap.get("name");
//		System.out.println("Value" + value);
//
//		//driver.getWindowHandles();
//		Set<String> keySetValues= hMap.keySet();
//		System.out.println(keySetValues.size());
//		
//		for(String s: keySetValues)
//		{
//			System.out.println("key:::"+ s +":::: value:::: "+ hMap.get(s));
//		}
//		
		
		
		
	}

}

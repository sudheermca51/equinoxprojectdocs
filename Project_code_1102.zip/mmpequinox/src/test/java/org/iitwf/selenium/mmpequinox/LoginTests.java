package org.iitwf.selenium.mmpequinox;

import org.iitwf.selenium.lib.FrameworkLibrary;
import org.iitwf.selenium.lib.MMPUtility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTests extends FrameworkLibrary {
//			id="username"
//			id="password"
//			name="submit"
//			//h3[normalize-space()='Patient Portal']
//
//			String expectedText = "Patient Portal";
	 
	public static void main(String args[])
	{
		WebDriver driver = new ChromeDriver();
		MMPUtility mmpUtil = new MMPUtility(driver);
		mmpUtil.login(prop.getProperty("patient_username"),prop.getProperty("patient_password"));
		String actualText = driver.findElement(By.xpath("//h3[normalize-space()='Patient Portal']")).getText();
		String expectedText = "Patient Portal";
		if(actualText.equals(expectedText))
		{
			System.out.println("Login Successful");
		}
		else
		{
			System.out.println("Login UnSuccessful");
		}
	}

}

package org.iitwf.selenium.lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

public class FrameworkLibrary {
	
	protected Properties prop;
	protected WebDriver driver;
	@BeforeTest
	public void readProperties() throws IOException {
		
		File f = new File("config//mmp_qa.properties");
		FileInputStream fis = new FileInputStream(f);
		prop = new Properties();
		prop.load(fis);
		System.out.println("patient username::: "+prop.getProperty("patient_username"));
	}
	@BeforeClass
	public void invokeDriverInstance()
	{
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 launchBrowser(prop.getProperty("patient_url"));
		 
	}
	public void launchBrowser(String url)
	{
		driver.get(url);
	}
	

}

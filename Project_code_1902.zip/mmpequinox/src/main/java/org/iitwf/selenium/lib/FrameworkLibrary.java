package org.iitwf.selenium.lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

public class FrameworkLibrary {
	
	protected Properties prop;
	protected WebDriver driver;
	String environment,browser;
	@BeforeTest
	public void readProperties() throws IOException
	{
		
		loadProperties("config//mmp_global.properties");
		environment = prop.getProperty("environment");
		browser = prop.getProperty("browser");
		if(environment.equals("dev"))
		{
			loadProperties("config//mmp_dev.properties");
		}
		else 
		{
			loadProperties("config//mmp_qa.properties");
		}
		
		System.out.println("patient username::: "+prop.getProperty("patient_username"));
	}
	
	public void loadProperties(String filePath) throws IOException
	{
		File f = new File(filePath);
		FileInputStream fis = new FileInputStream(f);
		prop = new Properties();
		prop.load(fis);
	}
	@BeforeClass
	public void invokeDriverInstance()
	{
		 
		 if(browser.equals("chrome"))
		 {
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 launchBrowser(prop.getProperty("patient_url"));
		 }
		 else
		 {
			 driver = new EdgeDriver();
			 driver.manage().window().maximize();
			 launchBrowser(prop.getProperty("patient_url"));
		 }
	}
	public void launchBrowser(String url)
	{
		driver.get(url);
	}
	

}

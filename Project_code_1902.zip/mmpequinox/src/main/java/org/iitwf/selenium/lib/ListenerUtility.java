package org.iitwf.selenium.lib;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class ListenerUtility extends TestListenerAdapter {
	
	@Override
	  public void onTestSuccess(ITestResult tr) {
		System.out.println("######################TestCase Passed " + tr.getName());
		System.out.println("Total Time in Execution:::" + tr.getEndMillis());
	    //ScreenshotUtil.captureScreenshot(tr.getName()+"_Pass");
	  }

	  @Override
	  public void onTestFailure(ITestResult tr) 
	  {
			System.out.println("######################TestCase Failed " + tr.getName());
			System.out.println("Total Time in Execution:::" + tr.getEndMillis());
		   // ScreenshotUtil.captureScreenshot(tr.getName()+"_Fail");
	  }


}

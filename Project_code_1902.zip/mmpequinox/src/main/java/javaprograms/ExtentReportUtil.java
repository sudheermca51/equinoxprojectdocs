package javaprograms;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportUtil {

	 
	    private static ExtentReports extent;

	    public static ExtentReports createInstance(String fileName) {
	        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
	        htmlReporter.setAppendExisting(true);  // Set to 'true' to append to existing report
	        extent = new ExtentReports();
	        extent.attachReporter(htmlReporter);
	        return extent;
	    }

	    public static ExtentReports getInstance() {
	        return extent;
	    }
	}
}

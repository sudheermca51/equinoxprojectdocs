package org.iitwf.selenium.mmpequinox;

import org.iitwf.mmp.pages.patientmodule.MMPUtility;
import org.iitwf.selenium.lib.FrameworkLibrary;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import javaprograms.RandomEx;

public class EditProfileTests extends FrameworkLibrary {
	static WebDriver driver = new ChromeDriver();
	 

	public static void main(String[] args) {
		MMPUtility mmpUtil = new MMPUtility(driver);
		mmpUtil.login(prop.getProperty("patient_username"),prop.getProperty("patient_password"));
		navigatetoAModule("Profile");
		editProfileTests();

	}
	public static void navigatetoAModule(String moduleName)
	{
		driver.findElement(By.xpath("//span[normalize-space()='"+moduleName+"']")).click();
	}
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}



/**
 * 1. update the firstname by passing randomtext value.
 * 	  expected and actual 
 *    compare expected vs actual
 *  
 * 2. LAstName
 * 3. SSN
 * 4. Address
 * 
 * SoftAssert 
 * 
 * FluentWait
 * Breakpoint by modifying the logic
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
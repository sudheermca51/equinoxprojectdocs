package org.iitwf.selenium.mmpequinox;

public class PatientApprovalProcess {
	/**
	 * registerPatient() - Tuesday 
loginToPatientModule()- Thursday
logintoAdminModule() - Thursday
approvePatient() - Thursday
loginToPatientModule()-Thursday
	 
	http://85.209.95.122/MMP-Release2-Admin-Build.2.1.000/login.php
	Ben@123
	Frank@123
	
	*/
}

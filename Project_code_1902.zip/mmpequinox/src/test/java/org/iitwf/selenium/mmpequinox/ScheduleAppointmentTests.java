package org.iitwf.selenium.mmpequinox;

import java.io.IOException;
import java.util.HashMap;

import org.iitwf.mmp.pages.patientmodule.HomePage;
import org.iitwf.mmp.pages.patientmodule.MMPUtility;
import org.iitwf.mmp.pages.patientmodule.ScheduleAppointmentPage;
import org.iitwf.selenium.lib.FrameworkLibrary;
import org.iitwf.selenium.lib.ListenerUtility;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenerUtility.class)
public class ScheduleAppointmentTests extends FrameworkLibrary{

	/*
	 * 
	 * Monday,Tuesday,Thursday - 9 pm 
	 * 
	 * 
	Formatted Date:::February/20/2025
	Same Year 
	Same Month -> Click on the date - 2
	----------------------------------------
	Formatted Date:::April/20/2025 - split("/") - [0] - April,[1]- 20,[2]-2025
	Same Year 
	Different Month - Expected Year - April -> Click on next button
	Different Month - Expected Year - December -> till i see the month as December 
	---------------------------------------------------------------------------------
	Formatted Date: April/20/2026
	Different Year - Click on next button till 2026 is displayed 
	Different Month - Click on next button till April is displayed 
	click on 20th as date 
	---------------------------------------------------------------------
	 */

	 
	@Test
	public void validateBookAppointmentTests() throws IOException 
	{
		MMPUtility mmpUtil = new MMPUtility(driver);
		mmpUtil.login(prop.getProperty("patient_username"),prop.getProperty("patient_password"));
		HomePage hPage = new HomePage(driver);
		hPage.navigatetoAModule("Schedule Appointment");
		ScheduleAppointmentPage sPage = new ScheduleAppointmentPage(driver);
		HashMap<String,String> expectedHMap= sPage.bookAppointment(60,"MMMM/d/YYYY","Cardiologist","Charlie");

		HashMap<String,String> actualHMap = hPage.fetchAppointmentDetails();
		Assert.assertEquals(actualHMap, expectedHMap,"Booking is unsuccessful");		 
	}
}


